# PostService README

## Use `docker-compose up --build` for the first time build this service
## mysql in docker is performed in 3306 port

## ensure the wait-for-it.sh can be run by using command `"chmod +x wait-for-it.sh"`

## Port number 9000

## Mysql port 3307

## Elasticsearch port 9200

## Run "Kibana" for elasticsearch visualization
`cd D:\Program Files (x86)\kibana-8.10.4\bin>`
`unix: ./kibana`
`window kibana.bat`
## Then use web browser localhost:5601 to visualize