//
//  CMU_XApp.swift
//  CMU-X
//
//  Created by Binhui Xu on 10/11/23.
//

import SwiftUI

@main
struct CMU_XApp: App {
    var body: some Scene {
        WindowGroup {
            LandingPage()
        }
    }
}
